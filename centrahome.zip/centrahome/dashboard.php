<?php
session_start();
include 'koneksi.php';

// Tambah Artikel
if (isset($_POST['tambah_artikel'])) {
    $judul = $_POST['judul'];
    $isi = $_POST['isi'];
    $kategori = $_POST['kategori'];
    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    if ($gambar != '') {
        move_uploaded_file($tmp, 'gambar_artikel/' . $gambar);
    }

    $conn->query("INSERT INTO artikel (judul, isi, kategori, gambar) 
                  VALUES ('$judul', '$isi', '$kategori', '$gambar')");
    header("Location: dashboard.php?page=artikel");
}

// Hapus Artikel
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $conn->query("DELETE FROM artikel WHERE id_artikel = $id");
    header("Location: dashboard.php?page=artikel");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Central</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      color: white;
    }
    .sidebar a {
      color: white;
      display: block;
      padding: 10px 15px;
      text-decoration: none;
    }
    .sidebar a:hover {
      background-color: #495057;
    }
    .content {
      padding: 20px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Central Dashboard</a>
    <a href="logout.php" class="btn btn-light btn-sm">Logout</a>
  </div>
</nav>

<!-- Layout -->
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <div class="col-md-2 sidebar">
      <h5 class="text-center mt-3">Menu</h5>
      <a href="dashboard.php?page=user">Data Pengguna</a>
      <a href="dashboard.php?page=artikel">Data Artikel</a>
      <a href="dashboard.php?page=tambah">Tambah Artikel</a>
    </div>

    <!-- Main Content -->
    <div class="col-md-10 content">
      <?php
      $page = isset($_GET['page']) ? $_GET['page'] : 'home';

      if ($page == 'user') {
        // Tampilkan data pengguna
        $result = $conn->query("SELECT COUNT(*) AS total FROM users");
        $row = $result->fetch_assoc();
        echo "<h4>Data Pengguna</h4>";
        echo "<p>Total user terdaftar: <strong>" . $row['total'] . "</strong></p>";

      } elseif ($page == 'tambah') {
        // Form tambah artikel
        ?>
        <h4>Tambah Artikel</h4>
        <form method="POST" enctype="multipart/form-data">
          <div class="mb-2">
            <label>Judul</label>
            <input type="text" name="judul" class="form-control" required>
          </div>
          <div class="mb-2">
            <label>Isi</label>
            <textarea name="isi" class="form-control" rows="3" required></textarea>
          </div>
          <div class="mb-2">
            <label>Kategori</label>
            <select name="kategori" class="form-control" required>
              <option value="Konsep">Konsep</option>
              <option value="Teknologi">Teknologi</option>
              <option value="Informasi">Informasi</option>
              <option value="Lainnya">Lainnya</option>
            </select>
          </div>
          <div class="mb-3">
            <label>Gambar</label>
            <input type="file" name="gambar" class="form-control">
          </div>
          <button type="submit" name="tambah_artikel" class="btn btn-success">Simpan Artikel</button>
        </form>
        <?php

      } elseif ($page == 'artikel') {
        // Tabel data artikel
        ?>
        <h4>Data Artikel</h4>
        <table class="table table-bordered table-striped mt-3">
          <thead class="table-dark">
            <tr>
              <th>No</th>
              <th>Judul</th>
              <th>Isi</th>
              <th>Kategori</th>
              <th>Tanggal</th>
              <th>Gambar</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 1;
            $data = $conn->query("SELECT * FROM artikel ORDER BY id_artikel DESC");
            while ($row = $data->fetch_assoc()) {
              echo "<tr>";
              echo "<td>" . $no++ . "</td>";
              echo "<td>" . $row['judul'] . "</td>";
              echo "<td>" . substr(strip_tags($row['isi']), 0, 100) . "...</td>";
              echo "<td>" . $row['kategori'] . "</td>";
              echo "<td>" . $row['tanggal_post'] . "</td>";
              echo "<td>";
              if ($row['gambar']) {
                echo "<img src='gambar_artikel/" . $row['gambar'] . "' class='img-thumbnail' style='width: 100px;'>";
              } else {
                echo "-";
              }
              echo "</td>";
              echo "<td>
                      <a href='edit_artikel.php?id=" . $row['id_artikel'] . "' class='btn btn-sm btn-warning'>Edit</a>
                      <a href='?page=artikel&hapus=" . $row['id_artikel'] . "' class='btn btn-sm btn-danger' onclick='return confirm(\"Hapus artikel ini?\")'>Hapus</a>
                    </td>";
              echo "</tr>";
            }
            ?>
          </tbody>
        </table>
        <?php

      } else {
        echo "<h4>Selamat Datang di Dashboard</h4>";
        echo "<p>Silakan pilih menu di sidebar untuk melihat data pengguna, artikel, atau menambah konten.</p>";
      }
      ?>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
