<?php
include 'koneksi.php';

if (!isset($_GET['id'])) {
    echo "ID Artikel tidak diberikan.";
    exit;
}

$id_artikel = intval($_GET['id']);
$query = mysqli_query($conn, "SELECT * FROM artikel WHERE id_artikel = $id_artikel");

if (!$query || mysqli_num_rows($query) == 0) {
    echo "Data artikel tidak ditemukan.";
    exit;
}

$data = mysqli_fetch_array($query);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = $_POST['judul'];
    $isi = $_POST['isi'];
    $kategori = $_POST['kategori'];

    // Proses gambar jika ada
    if ($_FILES['gambar']['name'] != '') {
        $gambar = $_FILES['gambar']['name'];
        $tmp = $_FILES['gambar']['tmp_name'];
        move_uploaded_file($tmp, "gambar_artikel/" . $gambar);
    } else {
        $gambar = $data['gambar']; // gambar lama
    }

    $update = mysqli_query($conn, "UPDATE artikel SET 
        judul = '$judul',
        isi = '$isi',
        kategori = '$kategori',
        gambar = '$gambar'
        WHERE id_artikel = $id_artikel");

    if ($update) {
        echo "<script>alert('Artikel berhasil diperbarui'); window.location='dashboard.php';</script>";
    } else {
        echo "Gagal mengupdate artikel.";
    }
}
?>

<h3>Edit Artikel</h3>
<form method="POST" enctype="multipart/form-data">
    Judul:<br>
    <input type="text" name="judul" value="<?= htmlspecialchars($data['judul']) ?>" required><br><br>

    Isi:<br>
    <textarea name="isi" rows="5" cols="50" required><?= htmlspecialchars($data['isi']) ?></textarea><br><br>

    Kategori:<br>
    <select name="kategori" required>
        <option value="Konsep" <?= $data['kategori'] == 'Konsep' ? 'selected' : '' ?>>Konsep</option>
        <option value="Teknologi" <?= $data['kategori'] == 'Teknologi' ? 'selected' : '' ?>>Teknologi</option>
        <option value="Informasi" <?= $data['kategori'] == 'Informasi' ? 'selected' : '' ?>>Informasi</option>
        <option value="Lainnya" <?= $data['kategori'] == 'Lainnya' ? 'selected' : '' ?>>Lainnya</option>
    </select><br><br>

    Gambar Sekarang:<br>
    <img src="gambar_artikel/<?= $data['gambar'] ?>" width="200"><br><br>

    Ganti Gambar (jika perlu):<br>
    <input type="file" name="gambar"><br><br>

    <input type="submit" value="Update Artikel">
</form>
