<!-- pages/event-galeri.php -->
<div class="container py-5">
  <h2 class="text-center mb-4 fw-bold">Galeri Event & Kegiatan</h2>
  <p class="text-center text-muted mb-5">
    Berikut adalah dokumentasi berbagai kegiatan, pameran, dan event promosi yang telah kami ikuti.
  </p>

  <!-- Baris Galeri ke Samping -->
  <div class="d-flex overflow-auto gap-4 px-2">
    <!-- Galeri 1 -->
    <div class="card shadow-sm border-0" style="min-width: 300px;">
      <img src="assets/img/event1.jpg" class="card-img-top" alt="Event 1">
      <div class="card-body">
        <h5 class="card-title">Pameran Perabot 2024</h5>
        <p class="card-text text-muted">Event pameran nasional di Jakarta Convention Center.</p>
      </div>
    </div>

    <!-- Galeri 2 -->
    <div class="card shadow-sm border-0" style="min-width: 300px;">
      <img src="assets/img/event2.jpg" class="card-img-top" alt="Event 2">
      <div class="card-body">
        <h5 class="card-title">Pelatihan Desain Interior</h5>
        <p class="card-text text-muted">Workshop bersama desainer interior profesional.</p>
      </div>
    </div>

    <!-- Galeri 3 -->
    <div class="card shadow-sm border-0" style="min-width: 300px;">
      <img src="assets/img/event3.jpg" class="card-img-top" alt="Event 3">
      <div class="card-body">
        <h5 class="card-title">CSR & Kegiatan Sosial</h5>
        <p class="card-text text-muted">Donasi perabot ke panti asuhan dalam program CSR.</p>
      </div>
    </div>
  </div>
</div>
