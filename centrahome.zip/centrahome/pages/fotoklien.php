<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Foto Klien</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

  <div class="container my-5">
    <h2 class="text-center mb-4">Galeri Foto Klien</h2>
    
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card shadow-sm">
          <img src="assets/img/klien1.jpg" alt="Klien 1">
          <div class="card-body">
            <h5 class="card-title">Klien 1</h5>
            <p class="card-text">Pelanggan dari Sambas, Kalimantan Barat.</p>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card shadow-sm">
          <img src="assets/img/klien2.jpg" alt="Klien 2">
          <div class="card-body">
            <h5 class="card-title">Klien 2</h5>
            <p class="card-text">Membeli satu set meja makan dari produk kami.</p>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card shadow-sm">
          <img src="assets/img/klien3.jpg" alt="Klien 3">
          <div class="card-body">
            <h5 class="card-title">Klien 3</h5>
            <p class="card-text">Menggunakan lemari custom dari produk unggulan kami.</p>
          </div>
        </div>
      </div>
    </div>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
