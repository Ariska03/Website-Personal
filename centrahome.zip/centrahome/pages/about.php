<!-- about.php -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - Parabot Kita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Parabot Kita</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarNav" aria-controls="navbarNav"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Hero Section -->
<section class="py-5 bg-light text-center">
    <div class="container">
        <h1 class="display-5 fw-bold">Tentang Kami</h1>
        <p class="lead">Kenali lebih dekat dengan perusahaan kami</p>
    </div>
</section>

<!-- Main Content -->
<section class="py-5">
    <div class="container">
        <div class="row g-4 align-items-center">
            <div class="col-md-6">
                <img src="assets/logo.png" alt="Logo Perusahaan" class="img-fluid rounded shadow">
            </div>
            <div class="col-md-6">
                <h3 class="fw-bold mb-3">Sejarah Singkat Kami</h3>
                <p>
                    Parabot Kita didirikan pada tahun 2015 di Sambas, Kalimantan Barat, sebagai perusahaan lokal yang fokus pada produksi dan distribusi perabot rumah tangga berkualitas tinggi. 
                    Berawal dari industri rumahan, kini kami telah berkembang menjadi salah satu penyedia utama kebutuhan perabot di wilayah Kalimantan.
                </p>
                <p>
                    Dengan mengusung prinsip inovasi, kualitas, dan pelayanan terbaik, kami terus berupaya memenuhi kebutuhan masyarakat akan perabot rumah yang fungsional dan estetis.
                </p>
                <p>
                    Kami bergerak di bidang pembuatan dan penjualan perabot rumah seperti lemari, meja, kursi, rak, dan produk custom sesuai permintaan pelanggan.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
    <p class="mb-0">Design by ARISKA | &copy; <?= date("Y"); ?> Parabot Kita</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
