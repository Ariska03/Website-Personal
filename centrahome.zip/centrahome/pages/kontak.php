<!-- kontak.php -->
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kontak Kami - Parabot Rumah</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">Parabot Rumah</a>
  </div>
</nav>

<!-- Kontak -->
<div class="container mt-5 mb-5">
  <h2 class="text-center mb-4">Hubungi Kami</h2>
  <div class="row">
    <!-- Form Kontak -->
    <div class="col-md-6">
      <form>
        <div class="mb-3">
          <label for="nama" class="form-label">Nama Lengkap</label>
          <input type="text" class="form-control" id="nama" placeholder="Masukkan nama Anda">
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Alamat Email</label>
          <input type="email" class="form-control" id="email" placeholder="contoh@email.com">
        </div>
        <div class="mb-3">
          <label for="pesan" class="form-label">Pesan</label>
          <textarea class="form-control" id="pesan" rows="4" placeholder="Tulis pesan Anda di sini..."></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Kirim Pesan</button>
      </form>
    </div>

    <!-- Info Kontak -->
    <div class="col-md-6">
      <div class="card p-4">
        <h5>Informasi Kontak</h5>
        <p><strong>Alamat:</strong> Jl. Raya Sambas No.123, Kalimantan Barat</p>
        <p><strong>Telepon:</strong> (0562) 123456 / 0812-3456-7890</p>
        <p><strong>Email:</strong> info@parabotrumah.com</p>
        <hr>
        <h6>Ikuti Kami</h6>
        <a href="#" class="btn btn-outline-dark btn-sm me-2"><i class="bi bi-facebook"></i> Facebook</a>
        <a href="#" class="btn btn-outline-dark btn-sm me-2"><i class="bi bi-instagram"></i> Instagram</a>
        <a href="#" class="btn btn-outline-dark btn-sm"><i class="bi bi-whatsapp"></i> WhatsApp</a>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
  Design by Ariska © <?= date('Y'); ?>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Icon (optional if pakai icon) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</body>
</html>
