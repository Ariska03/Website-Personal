<div class="container mt-5">
  <h2 class="text-center mb-4">Produk Kami</h2>
  <div class="row">

    <!-- Produk 1 -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm">
        <img src="assets/img/kursi.jpg" class="card-img-top" alt="Kursi Kayu">
        <div class="card-body">
          <h5 class="card-title">Kursi Kayu Jati</h5>
          <p class="card-text">Kursi elegan berbahan kayu jati asli, cocok untuk ruang tamu atau ruang makan.</p>
        </div>
      </div>
    </div>


    <!-- Produk 4 -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm">
        <img src="assets/img/rak_tv.jpg" class="card-img-top" alt="Rak TV">
        <div class="card-body">
          <h5 class="card-title">Rak TV Minimalis</h5>
          <p class="card-text">Rak TV stylish dengan ruang penyimpanan tambahan di bawahnya.</p>
        </div>
      </div>
    </div>

    
    <!-- Produk 3 -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm">
        <img src="assets/img/lemari.jpg" class="card-img-top" alt="Lemari Pakaian">
        <div class="card-body">
          <h5 class="card-title">Lemari Pakaian 3 Pintu</h5>
          <p class="card-text">Lemari besar berbahan kuat dengan banyak ruang penyimpanan.</p>
        </div>
      </div>
    </div>

    <!-- Produk 2 -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm">
        <img src="assets/img/meja.jpg" class="card-img-top" alt="Meja Minimalis">
        <div class="card-body">
          <h5 class="card-title">Meja Minimalis</h5>
          <p class="card-text">Desain simpel dan modern, cocok untuk ruang kerja atau ruang belajar.</p>
        </div>
      </div>
    </div>

    <!-- Produk 5 -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm">
        <img src="assets/img/tempat_tidur.jpg" class="card-img-top" alt="Tempat Tidur">
        <div class="card-body">
          <h5 class="card-title">Tempat Tidur Queen Size</h5>
          <p class="card-text">Nyaman dan kokoh, dirancang untuk kenyamanan istirahat Anda.</p>
        </div>
      </div>
    </div>

    <!-- Produk 6 -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm">
        <img src="assets/img/kitchen_set.jpg" class="card-img-top" alt="Kitchen Set">
        <div class="card-body">
          <h5 class="card-title">Kitchen Set Modern</h5>
          <p class="card-text">Solusi dapur lengkap dan elegan untuk hunian Anda.</p>
        </div>
      </div>
    </div>

  </div>
</div>
