<div class="container mt-5">
  <div class="row align-items-center">
    <div class="col-md-4 text-center">
      <!-- Ganti 'logo.png' dengan nama file logo Anda -->
      <img src="assets/logo.png" alt="Logo Perusahaan" class="img-fluid rounded shadow-sm" style="max-width: 200px;">
    </div>
    <div class="col-md-8">
      <h2>Profil Perusahaan</h2>
      <p>
        <strong>Rumah Indah Parabot</strong> adalah perusahaan yang bergerak di bidang penyediaan perabot rumah tangga yang elegan, fungsional, dan berkualitas tinggi. Berdiri sejak tahun 2015 di Kabupaten Sambas, perusahaan ini hadir untuk menjawab kebutuhan masyarakat akan produk perabot rumah yang modern namun tetap terjangkau.
      </p>
      <p>
        Dengan semangat pelayanan terbaik, Rumah Indah Parabot mengedepankan kepuasan pelanggan, inovasi desain, serta pemanfaatan bahan ramah lingkungan dalam setiap proses produksinya.
      </p>
      <p>
        Kami terus tumbuh dan berkembang dengan visi menjadi pelopor perabot rumah tangga lokal yang unggul dan dipercaya oleh masyarakat di seluruh Indonesia.
      </p>
    </div>
  </div>
</div>
