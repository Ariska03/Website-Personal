<!-- pages/visi.php -->
<div class="container mt-5">
    <div class="text-center mb-5">
        <h2 class="display-5 fw-bold">Visi & Misi Perusahaan</h2>
        <p class="lead text-muted">Menjadi yang terbaik dalam bidang parabot rumah tangga.</p>
    </div>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <h4 class="card-title text-primary">Visi Kami</h4>
                    <p class="card-text">Menjadi perusahaan terdepan dan terpercaya dalam menyediakan produk parabot rumah tangga berkualitas tinggi yang inovatif, estetis, dan ramah lingkungan untuk memenuhi kebutuhan masyarakat modern.</p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <h4 class="card-title text-success">Misi Kami</h4>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">✔ Mengutamakan kualitas produk dan pelayanan terbaik untuk pelanggan.</li>
                        <li class="list-group-item">✔ Mengembangkan desain produk yang fungsional dan modern.</li>
                        <li class="list-group-item">✔ Menjalin kerja sama berkelanjutan dengan mitra bisnis dan klien.</li>
                        <li class="list-group-item">✔ Meningkatkan kesejahteraan karyawan melalui lingkungan kerja yang sehat dan produktif.</li>
                        <li class="list-group-item">✔ Berkontribusi terhadap pelestarian lingkungan dengan produk ramah lingkungan.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
